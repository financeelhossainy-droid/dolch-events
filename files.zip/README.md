# Hall CRM System - Project Structure

```
hall_crm/
├── manage.py
├── hall_crm/
│   ├── settings.py
│   └── urls.py
├── core/           # القاعات - المناسبات - الخدمات - التسعير
│   ├── models.py
│   └── admin.py
└── bookings/       # العملاء - الحجوزات
    ├── models.py
    └── admin.py
```
