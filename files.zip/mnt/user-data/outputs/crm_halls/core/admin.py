from django.contrib import admin
from .models import Hall, OccasionType, Service, MainServicePrice, ExtraServicePrice, FixedServicePrice


# ─────────────────────────────────────────
# القاعات
# ─────────────────────────────────────────
@admin.register(Hall)
class HallAdmin(admin.ModelAdmin):
    list_display  = ("get_name_display", "is_active")
    list_filter   = ("is_active",)
    search_fields = ("name",)


# ─────────────────────────────────────────
# أنواع المناسبات
# ─────────────────────────────────────────
@admin.register(OccasionType)
class OccasionTypeAdmin(admin.ModelAdmin):
    list_display  = ("get_name_display", "is_active")
    list_filter   = ("is_active",)
    search_fields = ("name",)


# ─────────────────────────────────────────
# الخدمات
# ─────────────────────────────────────────
@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display  = ("get_name_display", "service_type", "is_hall_based", "is_active")
    list_filter   = ("service_type", "is_hall_based", "is_active")
    search_fields = ("name",)


# ─────────────────────────────────────────
# أسعار إيجار القاعة
# ─────────────────────────────────────────
@admin.register(MainServicePrice)
class MainServicePriceAdmin(admin.ModelAdmin):
    list_display  = ("hall", "occasion_type", "price", "is_active")
    list_filter   = ("hall", "occasion_type", "is_active")
    search_fields = ("hall__name", "occasion_type__name")


# ─────────────────────────────────────────
# أسعار الخدمات الإضافية (حسب القاعة)
# ─────────────────────────────────────────
@admin.register(ExtraServicePrice)
class ExtraServicePriceAdmin(admin.ModelAdmin):
    list_display  = ("service", "hall", "price", "is_active")
    list_filter   = ("hall", "is_active")
    search_fields = ("service__name", "hall__name")


# ─────────────────────────────────────────
# أسعار الخدمات الإضافية الثابتة
# ─────────────────────────────────────────
@admin.register(FixedServicePrice)
class FixedServicePriceAdmin(admin.ModelAdmin):
    list_display  = ("service", "price", "is_active")
    list_filter   = ("is_active",)
    search_fields = ("service__name",)
