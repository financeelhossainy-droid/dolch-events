from django.db import models


# ─────────────────────────────────────────
# القاعات
# ─────────────────────────────────────────
class Hall(models.Model):
    class HallName(models.TextChoices):
        ROYAL   = "royal",   "القاعة الملكية"
        DIAMOND = "diamond", "القاعة الماسية"

    name      = models.CharField(max_length=20, choices=HallName.choices, unique=True, verbose_name="اسم القاعة")
    is_active = models.BooleanField(default=True, verbose_name="مفعّلة")

    class Meta:
        verbose_name        = "قاعة"
        verbose_name_plural = "القاعات"

    def __str__(self):
        return self.get_name_display()


# ─────────────────────────────────────────
# أنواع المناسبات
# ─────────────────────────────────────────
class OccasionType(models.Model):
    class OccasionName(models.TextChoices):
        WEDDING         = "wedding",     "فرح إسلامي"
        MARRIAGE_CONTRACT = "contract",  "كتب كتاب"
        CONDOLENCE      = "condolence",  "عزاء"
        AQEEQA          = "aqeeqa",      "عقيقة"
        BUSINESS_MEETING = "meeting",    "اجتماعات عمل"

    name      = models.CharField(max_length=30, choices=OccasionName.choices, unique=True, verbose_name="نوع المناسبة")
    is_active = models.BooleanField(default=True, verbose_name="مفعّل")

    class Meta:
        verbose_name        = "نوع مناسبة"
        verbose_name_plural = "أنواع المناسبات"

    def __str__(self):
        return self.get_name_display()


# ─────────────────────────────────────────
# الخدمات
# ─────────────────────────────────────────
class Service(models.Model):
    class ServiceType(models.TextChoices):
        MAIN  = "main",  "خدمة رئيسية (إيجار القاعة)"
        EXTRA = "extra", "خدمة إضافية"

    class ServiceName(models.TextChoices):
        HALL_RENTAL  = "hall_rental",  "إيجار القاعة"
        DECORATION   = "decoration",   "ديكور"
        ZAFFA        = "zaffa",        "زفة"
        PHOTOGRAPHY  = "photography",  "تصوير"
        BEVERAGES    = "beverages",    "مشروبات"
        MEALS        = "meals",        "وجبات"

    name           = models.CharField(max_length=30, choices=ServiceName.choices, unique=True, verbose_name="اسم الخدمة")
    service_type   = models.CharField(max_length=10, choices=ServiceType.choices, verbose_name="نوع الخدمة")
    is_hall_based  = models.BooleanField(
        default=False,
        verbose_name="سعرها يختلف حسب القاعة",
        help_text="فعّل إذا كان سعر الخدمة يتغير بناءً على القاعة المختارة"
    )
    is_active      = models.BooleanField(default=True, verbose_name="مفعّلة")

    class Meta:
        verbose_name        = "خدمة"
        verbose_name_plural = "الخدمات"

    def __str__(self):
        return self.get_name_display()


# ─────────────────────────────────────────
# تسعير الخدمة الرئيسية (إيجار القاعة)
# حسب القاعة × نوع المناسبة
# ─────────────────────────────────────────
class MainServicePrice(models.Model):
    hall          = models.ForeignKey(Hall, on_delete=models.PROTECT, verbose_name="القاعة", related_name="prices")
    occasion_type = models.ForeignKey(OccasionType, on_delete=models.PROTECT, verbose_name="نوع المناسبة", related_name="prices")
    price         = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="السعر (جنيه)")
    is_active     = models.BooleanField(default=True, verbose_name="مفعّل")

    class Meta:
        verbose_name        = "سعر إيجار"
        verbose_name_plural = "أسعار الإيجار"
        unique_together     = ("hall", "occasion_type")

    def __str__(self):
        return f"{self.hall} | {self.occasion_type} → {self.price} ج"


# ─────────────────────────────────────────
# تسعير الخدمات الإضافية التي تعتمد على القاعة
# ─────────────────────────────────────────
class ExtraServicePrice(models.Model):
    service   = models.ForeignKey(
        Service, on_delete=models.PROTECT, verbose_name="الخدمة",
        related_name="hall_prices",
        limit_choices_to={"is_hall_based": True, "service_type": Service.ServiceType.EXTRA}
    )
    hall      = models.ForeignKey(Hall, on_delete=models.PROTECT, verbose_name="القاعة", related_name="extra_prices")
    price     = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="السعر (جنيه)")
    is_active = models.BooleanField(default=True, verbose_name="مفعّل")

    class Meta:
        verbose_name        = "سعر خدمة إضافية (حسب القاعة)"
        verbose_name_plural = "أسعار الخدمات الإضافية (حسب القاعة)"
        unique_together     = ("service", "hall")

    def __str__(self):
        return f"{self.service} | {self.hall} → {self.price} ج"


# ─────────────────────────────────────────
# تسعير الخدمات الإضافية ذات السعر الثابت
# ─────────────────────────────────────────
class FixedServicePrice(models.Model):
    service   = models.OneToOneField(
        Service, on_delete=models.PROTECT, verbose_name="الخدمة",
        related_name="fixed_price",
        limit_choices_to={"is_hall_based": False, "service_type": Service.ServiceType.EXTRA}
    )
    price     = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="السعر الثابت (جنيه)")
    is_active = models.BooleanField(default=True, verbose_name="مفعّل")

    class Meta:
        verbose_name        = "سعر ثابت لخدمة إضافية"
        verbose_name_plural = "أسعار ثابتة للخدمات الإضافية"

    def __str__(self):
        return f"{self.service} → {self.price} ج (ثابت)"
