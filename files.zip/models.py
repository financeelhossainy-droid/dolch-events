from django.db import models
from django.core.validators import RegexValidator
from core.models import Hall, OccasionType, Service


# ─────────────────────────────────────────
# العملاء
# ─────────────────────────────────────────
phone_validator = RegexValidator(
    regex=r"^01[0125]\d{8}$",
    message="أدخل رقم هاتف مصري صحيح (مثال: 01012345678)"
)

class Client(models.Model):
    name        = models.CharField(max_length=100, verbose_name="اسم العميل")
    phone       = models.CharField(max_length=11, validators=[phone_validator], unique=True, verbose_name="رقم الهاتف")
    notes       = models.TextField(blank=True, verbose_name="ملاحظات")
    created_at  = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإضافة")

    class Meta:
        verbose_name        = "عميل"
        verbose_name_plural = "العملاء"
        ordering            = ["-created_at"]

    def __str__(self):
        return f"{self.name} ({self.phone})"


# ─────────────────────────────────────────
# الحجوزات
# ─────────────────────────────────────────
class Booking(models.Model):
    class BookingStatus(models.TextChoices):
        PENDING   = "pending",   "قيد المراجعة"
        CONFIRMED = "confirmed", "مؤكد"
        CANCELLED = "cancelled", "ملغي"
        COMPLETED = "completed", "منتهي"

    # ── المعلومات الأساسية ──
    client         = models.ForeignKey(Client, on_delete=models.PROTECT, verbose_name="العميل", related_name="bookings")
    hall           = models.ForeignKey(Hall, on_delete=models.PROTECT, verbose_name="القاعة", related_name="bookings")
    occasion_type  = models.ForeignKey(OccasionType, on_delete=models.PROTECT, verbose_name="نوع المناسبة", related_name="bookings")

    # ── التواريخ ──
    booking_date   = models.DateField(verbose_name="تاريخ الحجز", help_text="اليوم الذي تم فيه الحجز")
    occasion_date  = models.DateField(verbose_name="تاريخ المناسبة", help_text="اليوم الفعلي للمناسبة")

    # ── الحالة ──
    status         = models.CharField(max_length=15, choices=BookingStatus.choices, default=BookingStatus.PENDING, verbose_name="حالة الحجز")

    # ── المالية ──
    total_price    = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name="إجمالي السعر (جنيه)")
    amount_paid    = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name="المبلغ المدفوع (جنيه)")

    # ── ملاحظات ──
    notes          = models.TextField(blank=True, verbose_name="ملاحظات")
    created_at     = models.DateTimeField(auto_now_add=True, verbose_name="وقت الإنشاء")
    updated_at     = models.DateTimeField(auto_now=True, verbose_name="آخر تحديث")

    class Meta:
        verbose_name        = "حجز"
        verbose_name_plural = "الحجوزات"
        ordering            = ["-occasion_date"]
        # منع تكرار نفس القاعة في نفس يوم المناسبة
        unique_together     = ("hall", "occasion_date")

    def __str__(self):
        return f"حجز #{self.pk} | {self.client.name} | {self.hall} | {self.occasion_date}"

    @property
    def remaining_amount(self):
        return self.total_price - self.amount_paid


# ─────────────────────────────────────────
# الخدمات المرتبطة بالحجز (BookingService)
# ─────────────────────────────────────────
class BookingService(models.Model):
    booking       = models.ForeignKey(Booking, on_delete=models.CASCADE, verbose_name="الحجز", related_name="services")
    service       = models.ForeignKey(Service, on_delete=models.PROTECT, verbose_name="الخدمة")
    unit_price    = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="سعر الوحدة (جنيه)")
    quantity      = models.PositiveSmallIntegerField(default=1, verbose_name="الكمية")
    notes         = models.CharField(max_length=255, blank=True, verbose_name="ملاحظة")

    class Meta:
        verbose_name        = "خدمة في الحجز"
        verbose_name_plural = "خدمات الحجز"

    def __str__(self):
        return f"{self.service} × {self.quantity} = {self.line_total} ج"

    @property
    def line_total(self):
        return self.unit_price * self.quantity
