# ─────────────────────────────────────────
# أضف هذا في settings.py → INSTALLED_APPS
# ─────────────────────────────────────────

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # ── Apps المشروع ──
    "core",
    "bookings",
]

LANGUAGE_CODE = "ar"
TIME_ZONE     = "Africa/Cairo"
USE_I18N      = True
USE_TZ        = True


# ─────────────────────────────────────────
# hall_crm/urls.py
# ─────────────────────────────────────────
from django.contrib import admin
from django.urls import path

admin.site.site_header = "نظام إدارة القاعة"
admin.site.site_title  = "CRM القاعة"
admin.site.index_title = "لوحة التحكم"

urlpatterns = [
    path("admin/", admin.site.urls),
]
