from django.contrib import admin
from django.utils.html import format_html
from .models import Client, Booking, BookingService


# ─────────────────────────────────────────
# Inline: خدمات الحجز داخل صفحة الحجز
# ─────────────────────────────────────────
class BookingServiceInline(admin.TabularInline):
    model       = BookingService
    extra       = 1
    fields      = ("service", "unit_price", "quantity", "notes")
    show_change_link = False


# ─────────────────────────────────────────
# العملاء
# ─────────────────────────────────────────
@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display   = ("name", "phone", "bookings_count", "created_at")
    list_filter    = ("created_at",)
    search_fields  = ("name", "phone")
    readonly_fields = ("created_at",)

    @admin.display(description="عدد الحجوزات")
    def bookings_count(self, obj):
        return obj.bookings.count()


# ─────────────────────────────────────────
# الحجوزات
# ─────────────────────────────────────────
@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display   = (
        "id", "client", "hall", "occasion_type",
        "booking_date", "occasion_date",
        "status_badge", "total_price", "amount_paid", "get_remaining"
    )
    list_filter    = ("status", "hall", "occasion_type", "occasion_date")
    search_fields  = ("client__name", "client__phone")
    readonly_fields = ("created_at", "updated_at", "get_remaining")
    date_hierarchy = "occasion_date"
    inlines        = [BookingServiceInline]

    fieldsets = (
        ("بيانات الحجز", {
            "fields": ("client", "hall", "occasion_type", "booking_date", "occasion_date", "status")
        }),
        ("المالية", {
            "fields": ("total_price", "amount_paid", "get_remaining")
        }),
        ("ملاحظات", {
            "fields": ("notes",),
            "classes": ("collapse",)
        }),
        ("معلومات النظام", {
            "fields": ("created_at", "updated_at"),
            "classes": ("collapse",)
        }),
    )

    @admin.display(description="المتبقي")
    def get_remaining(self, obj):
        remaining = obj.remaining_amount
        color = "red" if remaining > 0 else "green"
        return format_html('<span style="color:{}">{} ج</span>', color, remaining)

    @admin.display(description="الحالة")
    def status_badge(self, obj):
        colors = {
            "pending":   "#f0ad4e",
            "confirmed": "#5bc0de",
            "cancelled": "#d9534f",
            "completed": "#5cb85c",
        }
        color = colors.get(obj.status, "#999")
        return format_html(
            '<span style="background:{};color:#fff;padding:2px 8px;border-radius:4px;font-size:12px">{}</span>',
            color, obj.get_status_display()
        )
